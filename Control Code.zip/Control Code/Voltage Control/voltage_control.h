/*
************************************************************
* NOTE: Automatically generated file. DO NOT MODIFY!
************************************************************
*
* File: voltage_control.h
*
* Code generated from model             : 'tidalwithpid'.
* Subsystem selected for code generation: 'voltage_control'.
*
* Schematic Editor version              : 2023.1 SP1
* C source code generated on            : 17-Jul-2023 @ 01:58:56 AM
*
*/

#include "types.h"

// External input
typedef struct {
    // Generated from the component: Voltage control.Reference.out
    real_t _voltage_control_reference_out;
    // Generated from the component: Voltage control.From6
    real_t vout;
} voltage_control_ExtIn;


// External output
typedef struct {
    // Generated from the component: Voltage control.Goto2
    real_t reference;
} voltage_control_ExtOut;

// Sinks
typedef struct {
    // Generated from the component: Voltage control.Modulation Signal.in
    real_t _voltage_control_modulation_signal_in;
} voltage_control_ModelSinks;

// States
typedef struct {
    // Generated from the component: Voltage control.Integrator
    real_t _voltage_control_integrator__state;
} voltage_control_ModelStates;

// Model data structure
typedef struct {
    voltage_control_ExtIn *p_extIn;
    voltage_control_ExtOut *p_extOut;
    voltage_control_ModelSinks *p_Sinks;
    voltage_control_ModelStates *p_States;
} voltage_control_ModelData;

// External input
extern voltage_control_ExtIn voltage_control_ext_In;

// External output
extern voltage_control_ExtOut voltage_control_ext_Out;

// Sinks
extern voltage_control_ModelSinks voltage_control_m_Sinks;

// States
extern voltage_control_ModelStates voltage_control_m_States;

// Model data structure
extern voltage_control_ModelData voltage_control_m_Data;

// Model entry point functions
extern void voltage_control_init(voltage_control_ModelData *p_m_Data);
extern void voltage_control_step(voltage_control_ModelData *p_m_Data);
