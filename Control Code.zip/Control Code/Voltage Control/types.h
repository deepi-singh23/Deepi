/*
************************************************************
* NOTE: Automatically generated file. DO NOT MODIFY!
************************************************************
*
* File: voltage_control.h
*
* Code generated from model             : 'tidalwithpid'.
* Subsystem selected for code generation: 'voltage_control'.
*
* Schematic Editor version              : 2023.1 SP1
* C source code generated on            : 17-Jul-2023 @ 01:58:56 AM
*
*/

#include<math.h>

#ifndef PLATFORM_INFO
#define PLATFORM_NAME "generic"
#endif

#ifndef VOLTAGE_CONTROL_TYPES_H
#define VOLTAGE_CONTROL_TYPES_H

#include "custom_types.h"

// generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) (((value) > (limit)) ? (value) : (limit))
#endif
#ifndef MIN
#define MIN(value, limit) (((value) < (limit)) ? (value) : (limit))
#endif


#ifndef VOLTAGE_CONTROL_CUSTOM_TYPES_H
// Use default types
typedef int int_t;
typedef unsigned int uint_t;
typedef double real_t;
#endif

#endif
