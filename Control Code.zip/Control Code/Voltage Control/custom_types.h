/*
*
* This file contains custom definitions for types real, int and uint.
*
*
* File: voltage_control.h
*
* Code generated from model             : 'tidalwithpid'.
* Subsystem selected for code generation: 'voltage_control'.
*
* Schematic Editor version              : 2023.1 SP1
* C source code generated on            : 17-Jul-2023 @ 01:58:56 AM
*
*/

#ifndef VOLTAGE_CONTROL_CUSTOM_TYPES_H
#define VOLTAGE_CONTROL_CUSTOM_TYPES_H

// Type definitions
typedef int int_t;
typedef unsigned int uint_t;
typedef double real_t;

#endif  // VOLTAGE_CONTROL_CUSTOM_TYPES_H
