/*
************************************************************
* NOTE: Automatically generated file. DO NOT MODIFY!
************************************************************
*
* File: voltage_control.c
*
* Code generated from model             : 'tidalwithpid'.
* Subsystem selected for code generation: 'voltage_control'.
*
* Schematic Editor version              : 2023.1 SP1
* C source code generated on            : 17-Jul-2023 @ 01:58:56 AM
*
*/

#include "voltage_control.h"

//@cmp.def.start
// custom defines
//@cmp.def.end

// Model entry point functions
void voltage_control_step(voltage_control_ModelData *p_m_Data) {
    voltage_control_ExtIn *ext_In = (voltage_control_ExtIn *) p_m_Data->p_extIn;
    voltage_control_ExtOut *ext_Out = (voltage_control_ExtOut *) p_m_Data->p_extOut;
    voltage_control_ModelSinks *m_Sinks = (voltage_control_ModelSinks *) p_m_Data->p_Sinks;
    voltage_control_ModelStates *m_States = (voltage_control_ModelStates *) p_m_Data->p_States;
    //////////////////////////////////////////////////////////////////////////
    // Local variables
    //////////////////////////////////////////////////////////////////////////
    //@cmp.var.start
    real_t _voltage_control_integrator__out;
    real_t _voltage_control_range_shifter_const__out = 0.5;
    real_t _voltage_control_sum1__out;
    real_t _voltage_control_i__out;
    real_t _voltage_control_p__out;
    real_t _voltage_control_sum2__out;
    real_t _voltage_control_limit__out;
    real_t _voltage_control_range_shifter_gain1__out;
    real_t _voltage_control_range_shifter_sum3__out;
//@cmp.var.end
    //////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: Voltage control.Integrator
    _voltage_control_integrator__out = m_States->_voltage_control_integrator__state;
    // Generated from the component: Voltage control.Sum1
    _voltage_control_sum1__out = ext_In->_voltage_control_reference_out - ext_In->vout;
    // Generated from the component: Voltage control.I
    _voltage_control_i__out = 0.49 * _voltage_control_sum1__out;
    // Generated from the component: Voltage control.P
    _voltage_control_p__out = 0.006 * _voltage_control_sum1__out;
    // Generated from the component: Voltage control.Sum2
    _voltage_control_sum2__out = _voltage_control_p__out + _voltage_control_integrator__out;
    // Generated from the component: Voltage control.Limit
    _voltage_control_limit__out = MIN(MAX(_voltage_control_sum2__out, -0.6), 0.6);
    // Generated from the component: Voltage control.range shifter.Gain1
    _voltage_control_range_shifter_gain1__out = 0.5 * _voltage_control_limit__out;
    // Generated from the component: Voltage control.range shifter.Sum3
    _voltage_control_range_shifter_sum3__out = _voltage_control_range_shifter_gain1__out + _voltage_control_range_shifter_const__out;
///////////////
    // Update sinks
    ///////////////
    m_Sinks->_voltage_control_modulation_signal_in = _voltage_control_range_shifter_sum3__out;
    ////////////////
    // Update output
    ////////////////
    ext_Out->reference = _voltage_control_range_shifter_sum3__out;
    //@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: Voltage control.Integrator
    m_States->_voltage_control_integrator__state += _voltage_control_i__out * 0.0001;
//@cmp.update.block.end
}

void voltage_control_init(voltage_control_ModelData *p_m_Data) {
    //@cmp.init.block.start
    voltage_control_ModelStates *m_States = (voltage_control_ModelStates *) p_m_Data->p_States;
    m_States->_voltage_control_integrator__state = 0.0;
    //@cmp.init.block.end
}
