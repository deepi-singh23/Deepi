/*
************************************************************
* NOTE: Automatically generated file. DO NOT MODIFY!
************************************************************
*
* File: mppt.h
*
* Code generated from model             : 'tidal'.
* Subsystem selected for code generation: 'mppt'.
*
* Schematic Editor version              : 2023.1 SP1
* C source code generated on            : 17-Jul-2023 @ 01:54:45 AM
*
*/

#include<math.h>

#ifndef PLATFORM_INFO
#define PLATFORM_NAME "generic"
#endif

#ifndef MPPT_TYPES_H
#define MPPT_TYPES_H

#include "custom_types.h"

// generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) (((value) > (limit)) ? (value) : (limit))
#endif
#ifndef MIN
#define MIN(value, limit) (((value) < (limit)) ? (value) : (limit))
#endif


#ifndef MPPT_CUSTOM_TYPES_H
// Use default types
typedef int int_t;
typedef unsigned int uint_t;
typedef double real_t;
#endif

#endif
