/*
************************************************************
* NOTE: Automatically generated file. DO NOT MODIFY!
************************************************************
*
* File: mppt.h
*
* Code generated from model             : 'tidal'.
* Subsystem selected for code generation: 'mppt'.
*
* Schematic Editor version              : 2023.1 SP1
* C source code generated on            : 17-Jul-2023 @ 01:54:45 AM
*
*/

#include "types.h"

// External input
typedef struct {
    // Generated from the component: MPPT.From1
    real_t Idc;
    // Generated from the component: MPPT.From2
    real_t Vdc;
} mppt_ExtIn;


// External output
typedef struct {
    // Generated from the component: MPPT.Goto2
    real_t reference;
} mppt_ExtOut;

// Sinks
typedef struct {
    // Generated from the component: MPPT.P_pv.in
    real_t _mppt_p_pv_in;
    // Generated from the component: MPPT.reference_o.in
    real_t _mppt_reference_o_in;
    // Generated from the component: MPPT.Reference_out.in
    real_t _mppt_reference_out_in;
} mppt_ModelSinks;

// States
typedef struct {
    // Generated from the component: MPPT.Unit Delay1
    real_t _mppt_unit_delay1__state;

    // Generated from the component: MPPT.Unit Delay2
    real_t _mppt_unit_delay2__state;

    // Generated from the component: MPPT.P&O
    real_t _mppt_p_o__duty_cycle;
    real_t _mppt_p_o__delta_duty_cycle;
    real_t _mppt_p_o__min_val;
    real_t _mppt_p_o__max_val;
    real_t _mppt_p_o__step;

} mppt_ModelStates;

// Model data structure
typedef struct {
    mppt_ExtIn *p_extIn;
    mppt_ExtOut *p_extOut;
    mppt_ModelSinks *p_Sinks;
    mppt_ModelStates *p_States;
} mppt_ModelData;

// External input
extern mppt_ExtIn mppt_ext_In;

// External output
extern mppt_ExtOut mppt_ext_Out;

// Sinks
extern mppt_ModelSinks mppt_m_Sinks;

// States
extern mppt_ModelStates mppt_m_States;

// Model data structure
extern mppt_ModelData mppt_m_Data;

// Model entry point functions
extern void mppt_init(mppt_ModelData *p_m_Data);
extern void mppt_step(mppt_ModelData *p_m_Data);
