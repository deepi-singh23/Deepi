/*
*
* This file contains custom definitions for types real, int and uint.
*
*
* File: mppt.h
*
* Code generated from model             : 'tidal'.
* Subsystem selected for code generation: 'mppt'.
*
* Schematic Editor version              : 2023.1 SP1
* C source code generated on            : 17-Jul-2023 @ 01:54:20 AM
*
*/

#ifndef MPPT_CUSTOM_TYPES_H
#define MPPT_CUSTOM_TYPES_H

// Type definitions
typedef int int_t;
typedef unsigned int uint_t;
typedef double real_t;

#endif  // MPPT_CUSTOM_TYPES_H
