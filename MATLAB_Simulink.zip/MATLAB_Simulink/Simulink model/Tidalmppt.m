%% initialization
Ts_Power=1e-6;
Ts_Control=1e-6;
T_MPPT= 0.02;

%% Tidal/Gen Parameters
R=4;               %Turbine radius
Rs=0.09;           % Stator phase resistance(Ohm)
Ld=0.006033;       %Inductances [ Ld(H) Lq(H) ]
Lq=0.006668;       %Inductances [ Ld(H) Lq(H) ]
Phi= 1.2;          %Flux linkage (V.s)
J= 1;              %Inertia, , static friction(kg.m^2)  
F= 0.001889;       %viscous damping  (N.m.s) 
P=40;              %pole pairs

%% Converter parameters
L= 4.5573e-05;    %boost inductance
C= 6.6094e-04;    % boost capacitance
R_shunt=0.005;

%% Filter parameters
R_filter=0.2;
C_filter=500e-6;

open("Tidalfinalmppt.slx")