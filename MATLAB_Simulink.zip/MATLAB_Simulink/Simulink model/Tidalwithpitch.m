%%Initialization
Power=30e3 %power
R=5   % radius of turbine
G=4   % Gear ratio
rho=1025 % water density
J=0.121 % Rotor Inertia (Kg.m^2)
f=0.0073 % Friction coefficient   (N.m.s)
open('Tidalwithpitch1');
